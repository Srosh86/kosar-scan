import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import base64
import io
import json
import cv2
import numpy as np
import time  # برای پیگیری زمان فشار کلیدها
from scan_app.preview.style import AppStyle
from ..preview.style import AppStyle
from ..preview.resize_options import ResizeOptions

class PreviewWindow:
    def __init__(self, root, base64_image, on_confirm, client, name, name2, ws_server):
        self.root = root
        self.base64_image = base64_image
        self.on_confirm = on_confirm
        self.client = client
        self.name = name  # مثلاً hdffileForm
        self.name2 = name2  # مثلاً fileForm
        self.ws_server = ws_server
        self.image = None
        self.photo = None
        self.crop_coords = None
        self.rotation_angle = 0
        self.canvas_width = 500
        self.canvas_height = 400
        self.history = []  # تاریخچه تصاویر
        self.history_index = -1  # اندیس فعلی توی تاریخچه
        self.last_alt_press = 0  # زمان آخرین فشار کلید Alt
        self.alt_press_count = 0  # تعداد فشارهای متوالی کلید Alt
        self.canny_threshold = tk.IntVar(value=50)  # مقدار اولیه برای دقت Auto-Crop
        self.auto_crop_rect = None  # برای ذخیره مستطیل تشخیص خودکار

        # لاگ برای دیباگ
        print("Root object in PreviewWindow:", self.root)
        print("WebSocket Server:", self.ws_server)
        print("Received name:", self.name)
        print("Received name2:", self.name2)

        # تبدیل Base64 به تصویر
        image_data = base64.b64decode(base64_image)
        self.image = Image.open(io.BytesIO(image_data))
        self.original_image = self.image.copy()

        # ذخیره تصویر اولیه توی تاریخچه
        self.save_to_history()

        # تنظیم پنجره پیش‌نمایش
        self.preview_window = tk.Toplevel(self.root)
        self.preview_window.title("Scan Preview")
        self.preview_window.geometry("600x600")
        self.preview_window.configure(**AppStyle.FORM_STYLE)  # اعمال استایل فرم

        # نمایش تصویر
        self.canvas = tk.Canvas(self.preview_window, width=self.canvas_width, height=self.canvas_height, **AppStyle.CANVAS_STYLE)
        self.canvas.pack(pady=10)
        self.update_image()

        # دکمه‌های ویرایش
        edit_frame = tk.Frame(self.preview_window, **AppStyle.FORM_STYLE)
        edit_frame.pack(pady=5)

        # دکمه‌های ویرایش با استایل ثانویه
        crop_button = tk.Button(edit_frame, text="Crop", command=self.start_crop)
        AppStyle.apply_button_styles(crop_button, is_primary=False)
        crop_button.pack(side=tk.LEFT, padx=5)

        auto_crop_button = tk.Button(edit_frame, text="Auto-Crop", command=self.auto_crop)
        AppStyle.apply_button_styles(auto_crop_button, is_primary=False)
        auto_crop_button.pack(side=tk.LEFT, padx=5)

        rotate_right_button = tk.Button(edit_frame, text="Rotate 90°", command=lambda: self.rotate(90))
        AppStyle.apply_button_styles(rotate_right_button, is_primary=False)
        rotate_right_button.pack(side=tk.LEFT, padx=5)

        rotate_left_button = tk.Button(edit_frame, text="Rotate -90°", command=lambda: self.rotate(-90))
        AppStyle.apply_button_styles(rotate_left_button, is_primary=False)
        rotate_left_button.pack(side=tk.LEFT, padx=5)

        undo_button = tk.Button(edit_frame, text="Back", command=self.undo)
        AppStyle.apply_button_styles(undo_button, is_primary=False)
        undo_button.pack(side=tk.LEFT, padx=5)

        # دکمه‌های ثبت و لغو
        button_frame = tk.Frame(self.preview_window, **AppStyle.FORM_STYLE)
        button_frame.pack(pady=10)

        # دکمه‌ی ثبت با استایل اصلی
        confirm_button = tk.Button(button_frame, text="ثبت", command=self.confirm)
        AppStyle.apply_button_styles(confirm_button, is_primary=True)
        confirm_button.pack(side=tk.LEFT, padx=5)

        # دکمه‌ی لغو با استایل ثانویه
        cancel_button = tk.Button(button_frame, text="لغو", command=self.cancel)
        AppStyle.apply_button_styles(cancel_button, is_primary=False)
        cancel_button.pack(side=tk.LEFT, padx=5)

        # متغیرها برای برش
        self.start_x = None
        self.start_y = None
        self.rect = None
        self.canvas.bind("<ButtonPress-1>", self.on_press)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)

        # باند کردن میانبر Alt+Alt
        self.preview_window.bind("<Alt_L>", self.handle_alt_press)

    def handle_alt_press(self, event):
        current_time = time.time()
        # بررسی زمان بین دو فشار کلید (باید کمتر از 0.5 ثانیه باشه)
        if current_time - self.last_alt_press < 0.5:
            self.alt_press_count += 1
            if self.alt_press_count == 2:  # دو بار Alt پشت سر هم
                print("Alt+Alt detected, performing Auto-Crop")
                self.auto_crop()
                self.alt_press_count = 0  # ریست کردن شمارش
        else:
            self.alt_press_count = 1  # شروع شمارش جدید

        self.last_alt_press = current_time

    def auto_crop(self):
        # ذخیره تصویر قبل از برش خودکار توی تاریخچه
        self.save_to_history()

        # تبدیل تصویر PIL به فرمت OpenCV
        img_array = np.array(self.original_image)
        if len(img_array.shape) == 2:  # اگه تصویر خاکستریه
            img_array = cv2.cvtColor(img_array, cv2.COLOR_GRAY2BGR)
        else:
            img_array = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)

        # تبدیل به خاکستری و کاهش نویز
        gray = cv2.cvtColor(img_array, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)

        # پیدا کردن لبه‌ها با Canny
        edges = cv2.Canny(blurred, 50, 150)

        # پیدا کردن خطوط خارجی (contours)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        if not contours:
            messagebox.showwarning("Warning", "نمی‌توان محتوای اصلی را پیدا کرد. لطفاً از Crop دستی استفاده کنید.")
            return

        # پیدا کردن بزرگ‌ترین خط خارجی (محتوای اصلی)
        largest_contour = max(contours, key=cv2.contourArea)

        # محاسبه‌ی مستطیل دور محتوا
        x, y, w, h = cv2.boundingRect(largest_contour)

        # اضافه کردن یه حاشیه کوچک (padding) برای جلوگیری از برش تنگ
        padding = 10
        x = max(0, x - padding)
        y = max(0, y - padding)
        w = min(img_array.shape[1] - x, w + 2 * padding)
        h = min(img_array.shape[0] - y, h + 2 * padding)

        # لاگ برای دیباگ
        print(f"Auto-Crop bounding box: x={x}, y={y}, w={w}, h={h}")

        # برش تصویر
        cropped_array = img_array[y:y+h, x:x+w]

        # تبدیل تصویر OpenCV به PIL
        cropped_pil = Image.fromarray(cv2.cvtColor(cropped_array, cv2.COLOR_BGR2RGB))
        self.original_image = cropped_pil
        self.rotation_angle = 0
        self.update_image()

    def save_to_history(self):
        # حذف تاریخچه‌ی جلوتر (اگه کاربر برگشته باشه و تغییر جدید بده)
        if self.history_index < len(self.history) - 1:
            self.history = self.history[:self.history_index + 1]
        
        # ذخیره تصویر فعلی توی تاریخچه
        self.history.append(self.original_image.copy())
        self.history_index += 1

        # لاگ برای دیباگ
        print(f"Saved to history. Index: {self.history_index}, Total history: {len(self.history)}")

    def undo(self):
        if self.history_index <= 0:
            print("No more undo available")
            messagebox.showinfo("Info", "نمی‌توانید بیشتر از این به عقب برگردید")
            return

        self.history_index -= 1
        self.original_image = self.history[self.history_index].copy()
        self.rotation_angle = 0  # ریست کردن چرخش
        self.update_image()

        # لاگ برای دیباگ
        print(f"Undone to history index: {self.history_index}")

    def update_image(self):
        # کپی تصویر اصلی
        self.image = self.original_image.copy()
        self.image = self.image.rotate(self.rotation_angle, expand=True)

        # محاسبه نسبت ابعاد برای مقیاس‌بندی
        img_width, img_height = self.image.size
        aspect_ratio = img_width / img_height
        canvas_aspect = self.canvas_width / self.canvas_height

        if aspect_ratio > canvas_aspect:
            # تصویر عریض‌تره، عرض رو با Canvas تطبیق بده
            new_width = self.canvas_width
            new_height = int(new_width / aspect_ratio)
        else:
            # تصویر بلندتره، ارتفاع رو با Canvas تطبیق بده
            new_height = self.canvas_height
            new_width = int(new_height * aspect_ratio)

        # تغییر اندازه تصویر
        self.image = self.image.resize((new_width, new_height), Image.Resampling.LANCZOS)
        self.photo = ImageTk.PhotoImage(self.image)

        # محاسبه افست برای وسط‌چین کردن تصویر
        self.offset_x = (self.canvas_width - new_width) // 2
        self.offset_y = (self.canvas_height - new_height) // 2

        # لاگ برای دیباگ
        print(f"Image resized to: {new_width}x{new_height}")
        print(f"Offset: x={self.offset_x}, y={self.offset_y}")

        # نمایش تصویر روی Canvas
        self.canvas.delete("all")
        self.canvas.create_image(self.canvas_width // 2, self.canvas_height // 2, image=self.photo)

    def start_crop(self):
        self.crop_coords = None
        self.canvas.delete("rect")

    def on_press(self, event):
        self.start_x = event.x
        self.start_y = event.y
        self.rect = self.canvas.create_rectangle(self.start_x, self.start_y, self.start_x, self.start_y, outline="red", tags="rect")

    def on_drag(self, event):
        self.canvas.coords(self.rect, self.start_x, self.start_y, event.x, event.y)

    def on_release(self, event):
        end_x, end_y = event.x, event.y
        x1, y1 = min(self.start_x, end_x), min(self.start_y, end_y)
        x2, y2 = max(self.start_x, end_x), max(self.start_y, end_y)
        self.crop_coords = (x1, y1, x2, y2)

        if x2 > x1 and y2 > y1:
            # ذخیره تصویر قبل از برش توی تاریخچه
            self.save_to_history()

            # تنظیم مختصات نسبت به افست تصویر
            x1 -= self.offset_x
            y1 -= self.offset_y
            x2 -= self.offset_x
            y2 -= self.offset_y

            # محاسبه مقیاس واقعی تصویر روی Canvas
            displayed_width, displayed_height = self.image.size
            scale_x = self.original_image.width / displayed_width
            scale_y = self.original_image.height / displayed_height

            # تبدیل مختصات به مقیاس تصویر اصلی
            crop_box = (
                max(0, int(x1 * scale_x)),
                max(0, int(y1 * scale_y)),
                min(self.original_image.width, int(x2 * scale_x)),
                min(self.original_image.height, int(y2 * scale_y))
            )

            # لاگ برای دیباگ
            print(f"Crop coordinates on canvas: ({x1}, {y1}, {x2}, {y2})")
            print(f"Crop box on original image: {crop_box}")

            # اعمال برش
            self.original_image = self.original_image.crop(crop_box)
            self.rotation_angle = 0
            self.update_image()

    def rotate(self, angle):
        # ذخیره تصویر قبل از چرخش توی تاریخچه
        self.save_to_history()

        self.rotation_angle += angle
        self.update_image()

    def confirm(self):
        img_byte_arr = io.BytesIO()
        # ذخیره به‌صورت PNG برای جلوگیری از فشرده‌سازی مضاعف
        self.original_image.save(img_byte_arr, format="PNG")
        img_byte_arr = img_byte_arr.getvalue()
        final_base64 = base64.b64encode(img_byte_arr).decode('utf-8')

        # لاگ برای دیباگ
        print("Base64 length:", len(final_base64))
        print("Sending to WebSocket, client:", self.client)
        print("File Input ID (name2):", self.name2)

        # ارسال فقط رشته Base64 (مشابه سی‌شارپ)
        try:
            self.ws_server.notify_upload_success(self.client, final_base64)
            print("Sent: Base64 string only (PNG format)")
            messagebox.showinfo("Success", "Image sent to web application")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to send image: {str(e)}")

        self.on_confirm(final_base64, self.client, self.name, self.name2)
        self.preview_window.destroy()

    def cancel(self):
        self.preview_window.destroy()