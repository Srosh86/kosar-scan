import tkinter as tk
import win32gui
import win32con
import pywintypes
from PIL import Image

class SystemTray:
    def __init__(self, root):
        self.root = root
        self.hwnd = None
        self.icon_path = r"c:\Users\EMDAD-VALAYAT\Documents\PHYTHON\Scan\icon2.ico"
        self.running = True
        self.class_name = 'ScanServerTray'

    def show(self):
        # تعریف کلاس پنجره
        wc = win32gui.WNDCLASS()
        wc.lpszClassName = self.class_name
        wc.style = win32con.CS_VREDRAW | win32con.CS_HREDRAW
        wc.hCursor = win32gui.LoadCursor(0, win32con.IDC_ARROW)
        wc.hbrBackground = win32con.COLOR_WINDOW
        wc.lpfnWndProc = self.wnd_proc

        try:
            class_atom = win32gui.RegisterClass(wc)
        except pywintypes.error as e:
            if e.winerror != 1410:  # Class already exists
                raise
            # اگه کلاس از قبل وجود داره، می‌تونیم ادامه بدیم

        self.hwnd = win32gui.CreateWindow(
            self.class_name, 'Scan Server Tray',
            win32con.WS_OVERLAPPED | win32con.WS_SYSMENU,
            0, 0, win32con.CW_USEDEFAULT, win32con.CW_USEDEFAULT,
            0, 0, 0, None
        )

        hicon = win32gui.LoadImage(
            0, self.icon_path, win32con.IMAGE_ICON,
            0, 0, win32con.LR_LOADFROMFILE | win32con.LR_DEFAULTSIZE
        )

        nid = (self.hwnd, 0, win32gui.NIF_ICON | win32gui.NIF_MESSAGE | win32gui.NIF_TIP, win32con.WM_USER + 20, hicon, 'Scan Server')
        win32gui.Shell_NotifyIcon(win32gui.NIM_ADD, nid)

    def wnd_proc(self, hwnd, msg, wparam, lparam):
        if lparam == win32con.WM_LBUTTONUP:
            self.root.deiconify()
        elif lparam == win32con.WM_RBUTTONUP:
            menu = win32gui.CreatePopupMenu()
            win32gui.AppendMenu(menu, win32con.MF_STRING, 1001, "Show Window")
            win32gui.AppendMenu(menu, win32con.MF_STRING, 1002, "Exit")

            pos = win32gui.GetCursorPos()
            win32gui.SetForegroundWindow(hwnd)
            win32gui.TrackPopupMenu(menu, win32con.TPM_LEFTALIGN, pos[0], pos[1], 0, hwnd, None)
            win32gui.PostMessage(hwnd, win32con.WM_NULL, 0, 0)

            if win32gui.GetMenuItemID(menu, win32gui.GetMenuItemCount(menu) - 1) == 1002:
                self.exit_app()
            elif win32gui.GetMenuItemID(menu, win32gui.GetMenuItemCount(menu) - 2) == 1001:
                self.root.deiconify()

        return win32gui.DefWindowProc(hwnd, msg, wparam, lparam)

    def exit_app(self):
        self.running = False
        if self.hwnd:
            nid = (self.hwnd, 0)
            win32gui.Shell_NotifyIcon(win32gui.NIM_DELETE, nid)
            win32gui.DestroyWindow(self.hwnd)
        # آزاد کردن کلاس
        try:
            win32gui.UnregisterClass(self.class_name, None)
        except pywintypes.error as e:
            if e.winerror != 1410:  # Class does not exist
                raise
        win32gui.PostQuitMessage(0)
        self.root.quit()