import tkinter as tk
from scan_app.gui.system_tray import SystemTray
from scan_app.gui.preview_window import PreviewWindow

class MainWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("Scan Server")
        self.root.geometry("400x200")
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

        tk.Button(self.root, text="Run in Background", command=self.run_in_background).pack(pady=10)
        tk.Button(self.root, text="Exit", command=self.exit_app).pack(pady=10)

        self.tray = SystemTray(self.root)

    def on_scan_request(self, base64_image, client, name, name2):
        # لاگ برای دیباگ
        print(f"on_scan_request called with: name={name}, name2={name2}")
        # پاس دادن ws_server به PreviewWindow
        ws_server = self.root.ws_server
        PreviewWindow(self.root, base64_image, self.on_scan_confirmed, client, name, name2, ws_server)

    def on_scan_confirmed(self, final_base64, client, name, name2):
        pass

    def run_in_background(self):
        self.root.withdraw()
        self.tray.show()

    def on_closing(self):
        self.exit_app()

    def exit_app(self):
        self.tray.exit_app()