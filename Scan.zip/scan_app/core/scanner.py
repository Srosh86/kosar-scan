import pythoncom
import win32com.client
import os
import tempfile
from PIL import Image
import io
import base64

class Scanner:
    def scan_image(self, resolution=300, color_mode="Color"):
        try:
            pythoncom.CoInitialize()
            wia = win32com.client.Dispatch("WIA.CommonDialog")
            device = wia.ShowSelectDevice()
            item = device.Items[1]
            item.Properties("6147").Value = resolution  # X Resolution
            item.Properties("6148").Value = resolution  # Y Resolution
            item.Properties("6146").Value = 1 if color_mode == "Color" else 2  # Color mode
            image = item.Transfer("{B96B3CAE-0728-11D3-9D7B-0000F81EF32E}")  # JPEG
            temp_path = os.path.join(tempfile.gettempdir(), f"scan_{os.urandom(4).hex()}.jpg")
            image.SaveFile(temp_path)
            return self._resize_image(temp_path)
        except Exception as e:
            print(f"Scan error: {e}")
            return None
        finally:
            pythoncom.CoUninitialize()

    def _resize_image(self, image_path, max_width=1024, max_height=1024):
        try:
            with Image.open(image_path) as img:
                if img.size[0] > max_width or img.size[1] > max_height:
                    ratio = min(max_width / img.size[0], max_height / img.size[1])
                    new_size = (int(img.size[0] * ratio), int(img.size[1] * ratio))
                    img = img.resize(new_size, Image.LANCZOS)
                output = io.BytesIO()
                img.save(output, format="JPEG")
                return base64.b64encode(output.getvalue()).decode("utf-8")
        except Exception as e:
            print(f"Resize error: {e}")
            with open(image_path, "rb") as f:
                return base64.b64encode(f.read()).decode("utf-8")