import requests

class Uploader:
    def upload_image(self, base64_image, upload_url="http://localhost:8080/upload"):
        try:
            payload = {
                "image": base64_image,
                "filename": f"scan_{int(__import__('time').time() * 1000)}.jpg"
            }
            response = requests.post(upload_url, json=payload, headers={"Content-Type": "application/json"})
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"Upload error: {e}")
            return None