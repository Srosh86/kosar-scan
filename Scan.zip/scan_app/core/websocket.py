import websocket_server
from scan_app.core.scanner import Scanner
import logging
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("WebSocketServer")

class WebSocketServer:
    def __init__(self, on_scan_request):
        self.server = websocket_server.WebsocketServer(host="0.0.0.0", port=55755)
        self.scanner = Scanner()
        self.server.set_fn_message_received(self._on_message)
        self.on_scan_request = on_scan_request

    def run(self):
        logger.info("WebSocket server running on ws://0.0.0.0:55755")
        self.server.run_forever()

    def _on_message(self, client, server, message):
        logger.info(f"Received message: {message}")
        try:
            # parse کردن پیام JSON
            data = json.loads(message)
            logger.info(f"Parsed JSON data: {data}")
            msg = data.get("message")
            name = data.get("name")
            name2 = data.get("name2")
            
            # لاگ برای دیباگ
            logger.info(f"Extracted values: msg={msg}, name={name}, name2={name2}")
            
            if msg == "SCAN_GET_DATA":
                try:
                    base64_image = self.scanner.scan_image(resolution=300, color_mode="Color")
                    if base64_image:
                        self.on_scan_request(base64_image, client, name, name2)
                    else:
                        server.send_message(client, "ERROR:Scan failed")
                except Exception as e:
                    logger.error(f"Error processing scan: {str(e)}")
                    server.send_message(client, f"ERROR:{str(e)}")
        except json.JSONDecodeError:
            # اگه پیام JSON نباشه، مثل قبل رفتار کن
            logger.info("Message is not JSON, treating as plain text")
            if message == "SCAN_GET_DATA":
                try:
                    base64_image = self.scanner.scan_image(resolution=300, color_mode="Color")
                    if base64_image:
                        self.on_scan_request(base64_image, client, None, None)
                    else:
                        server.send_message(client, "ERROR:Scan failed")
                except Exception as e:
                    logger.error(f"Error processing scan: {str(e)}")
                    server.send_message(client, f"ERROR:{str(e)}")

    def notify_upload_success(self, client, message="IMAGE_READY"):
        self.server.send_message(client, message)