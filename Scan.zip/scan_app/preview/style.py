class AppStyle:
    # رنگ‌ها
    BACKGROUND_COLOR = "#2E2E2E"  # خاکستری تیره برای پس‌زمینه‌ی فرم
    BUTTON_PRIMARY_BG = "#4CAF50"  # سبز برای دکمه‌های اصلی (مثل "ثبت")
    BUTTON_PRIMARY_FG = "#FFFFFF"  # متن سفید روی دکمه‌های اصلی
    BUTTON_PRIMARY_HOVER_BG = "#45A049"  # سبز تیره‌تر برای هاور
    BUTTON_SECONDARY_BG = "#555555"  # خاکستری تیره برای دکمه‌های ثانویه (مثل "لغو" و دکمه‌های ویرایش)
    BUTTON_SECONDARY_FG = "#FFFFFF"  # متن سفید روی دکمه‌های ثانویه
    BUTTON_SECONDARY_HOVER_BG = "#4A90E2"  # آبی برای هاور دکمه‌های ثانویه
    TEXT_COLOR = "#FFFFFF"  # رنگ متن سفید برای خوانایی
    CANVAS_BORDER_COLOR = "#4A90E2"  # رنگ حاشیه‌ی Canvas (آبی)

    # استایل دکمه‌ها
    BUTTON_STYLE = {
        "font": ("Helvetica", 12, "bold"),
        "borderwidth": 0,
        "relief": "raised",  # اضافه کردن سایه برای افکت سه‌بعدی
        "cursor": "hand2",  # شکل دست برای کلیک
    }

    BUTTON_PRIMARY_STYLE = {
        **BUTTON_STYLE,
        "background": BUTTON_PRIMARY_BG,
        "foreground": BUTTON_PRIMARY_FG,
        "activebackground": BUTTON_PRIMARY_HOVER_BG,
        "activeforeground": BUTTON_PRIMARY_FG,
        "padx": 15,
        "pady": 8,  # افزایش pady برای دکمه‌های زیباتر
    }

    BUTTON_SECONDARY_STYLE = {
        **BUTTON_STYLE,
        "background": BUTTON_SECONDARY_BG,
        "foreground": BUTTON_SECONDARY_FG,
        "activebackground": BUTTON_SECONDARY_HOVER_BG,
        "activeforeground": BUTTON_SECONDARY_FG,
        "padx": 15,
        "pady": 8,
    }

    # استایل فرم
    FORM_STYLE = {
        "background": BACKGROUND_COLOR,
    }

    # استایل Canvas
    CANVAS_STYLE = {
        "background": "#1C2526",  # رنگ تیره‌تر برای Canvas
        "highlightbackground": CANVAS_BORDER_COLOR,
        "highlightthickness": 2,  # ضخامت حاشیه
    }

    @staticmethod
    def apply_button_styles(button, is_primary=True):
        """اعمال استایل به دکمه‌ها و اضافه کردن افکت هاور"""
        style = AppStyle.BUTTON_PRIMARY_STYLE if is_primary else AppStyle.BUTTON_SECONDARY_STYLE
        button.configure(**style)

        # ذخیره‌ی رنگ اولیه برای استفاده در هاور
        original_bg = style["background"]
        hover_bg = style["activebackground"]

        def on_enter(e):
            button.configure(background=hover_bg)

        def on_leave(e):
            button.configure(background=original_bg)

        button.bind("<Enter>", on_enter)
        button.bind("<Leave>", on_leave)

    @staticmethod
    def apply_round_corners(widget):
        """اعمال گوشه‌های گرد به ویجت (برای دکمه‌ها)"""
        widget.configure(relief="flat")
        # برای گوشه‌های گرد واقعی، باید از ttk استفاده کنیم یا ویجت رو بازطراحی کنیم
        # فعلاً با borderwidth=0 و سایه‌ی بصری شبیه‌سازی می‌کنیم