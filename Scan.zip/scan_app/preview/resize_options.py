import json
import os
from PIL import Image
import io

class ResizeOptions:
    # تنظیمات سایزهای پیش‌فرض (عرض در پیکسل)
    SIZES = {
        "کارت ملی": {"width": 500, "max_size": 50 * 1024},  # حداکثر 50KB
        "شناسنامه جدید": {"width": 600, "max_size": 50 * 1024},  # حداکثر 50KB
        "شناسنامه قدیم": {"width": 765, "max_size": 50 * 1024},  # عرض 765 پیکسل
        "کاغذ A5": {"width": 765, "max_size": 50 * 1024},  # حداکثر 50KB
        "کاغذ A4": {"width": 850, "max_size": 120 * 1024},  # حداکثر 120KB
        "سایز دلخواه": {"width": None, "max_size": None},  # بدون محدودیت
        "بدون تغییر سایز": {"width": None, "max_size": None},  # بدون محدودیت
    }

    SETTINGS_FILE = "resize_settings.json"

    def __init__(self):
        self.last_selected = self.load_last_selected()

    def load_last_selected(self):
        """بارگذاری آخرین گزینه‌ی انتخاب‌شده از فایل تنظیمات"""
        if os.path.exists(self.SETTINGS_FILE):
            with open(self.SETTINGS_FILE, "r") as f:
                data = json.load(f)
                return data.get("last_selected", "کارت ملی")
        return "کارت ملی"  # پیش‌فرض

    def save_last_selected(self, option):
        """ذخیره‌ی گزینه‌ی انتخاب‌شده توی فایل تنظیمات"""
        with open(self.SETTINGS_FILE, "w") as f:
            json.dump({"last_selected": option}, f)

    def resize_and_compress(self, image, selected_option, custom_width=None, custom_height=None, lock_aspect_ratio=False):
        """ریسایز و فشرده‌سازی تصویر بر اساس گزینه‌ی انتخاب‌شده"""
        img_width, img_height = image.size
        aspect_ratio = img_width / img_height

        # ریسایز بر اساس گزینه‌ی انتخاب‌شده
        if selected_option == "سایز دلخواه" and custom_width and custom_height:
            if lock_aspect_ratio:
                target_width = int(custom_width)
                target_height = int(target_width / aspect_ratio)
            else:
                target_width = int(custom_width)
                target_height = int(custom_height)
        elif selected_option == "بدون تغییر سایز":
            target_width = img_width
            target_height = img_height
        else:
            target_width = self.SIZES[selected_option]["width"]
            target_height = int(target_width / aspect_ratio) if target_width else img_height

        # اعمال ریسایز
        if target_width != img_width or target_height != img_height:
            resized_image = image.resize((target_width, target_height), Image.Resampling.LANCZOS)
            print(f"Resized image to: {target_width}x{target_height}")
        else:
            resized_image = image

        # فشرده‌سازی تصویر
        max_size = self.SIZES[selected_option]["max_size"]
        if max_size is None:  # بدون محدودیت حجم
            img_byte_arr = io.BytesIO()
            resized_image.save(img_byte_arr, format="JPEG", quality=85)
            return img_byte_arr.getvalue()

        # فشرده‌سازی با تنظیم کیفیت
        quality = 85
        min_quality = 10
        target_min_size = 50 * 1024 if selected_option != "کاغذ A4" else 0  # حداقل 50KB برای همه به جز A4

        while quality >= min_quality:
            img_byte_arr = io.BytesIO()
            resized_image.save(img_byte_arr, format="JPEG", quality=quality)
            size = img_byte_arr.tell()
            print(f"Image size with quality {quality}: {size} bytes")

            if size <= max_size and size >= target_min_size:
                return img_byte_arr.getvalue()
            elif size > max_size:
                quality -= 5
            else:
                quality += 5

        # اگه به کیفیت مناسب نرسیدیم، با آخرین کیفیت ذخیره کن
        img_byte_arr = io.BytesIO()
        resized_image.save(img_byte_arr, format="JPEG", quality=quality)
        print(f"Final image size with quality {quality}: {img_byte_arr.tell()} bytes")
        return img_byte_arr.getvalue()