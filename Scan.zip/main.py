import tkinter as tk
from scan_app.gui.main_window import MainWindow
from scan_app.core.websocket import WebSocketServer
import threading
import socket
import sys
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ScanServer")

def check_single_instance():
    lock_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        lock_socket.bind(('localhost', 55756))
    except socket.error:
        logger.error("Another instance of the program is already running.")
        sys.exit(1)
    return lock_socket

def main():
    lock_socket = check_single_instance()

    root = tk.Tk()
    app = MainWindow(root)

    logger.info("Starting WebSocket server...")
    ws_server = WebSocketServer(app.on_scan_request)
    root.ws_server = ws_server
    ws_thread = threading.Thread(target=ws_server.run, daemon=True)
    ws_thread.start()

    root.mainloop()

    lock_socket.close()

if __name__ == "__main__":
    main()